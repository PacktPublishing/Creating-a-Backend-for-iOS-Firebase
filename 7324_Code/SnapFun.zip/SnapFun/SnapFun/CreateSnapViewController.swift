//
//  CreateSnapViewController.swift
//  SnapFun
//
//  Created by zappycode on 5/12/18.
//  Copyright © 2018 Nick Walter. All rights reserved.
//

import UIKit
import FirebaseStorage

class CreateSnapViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var noteTextField: UITextField!
    
    var imagePicker = UIImagePickerController()
    var imageName = "\(NSUUID().uuidString).jpeg"
    var imageURL = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagePicker.delegate = self
    }
    
    @IBAction func nextTapped(_ sender: Any) {
        let imagesFolder = Storage.storage().reference().child("images")
        if let image = imageView.image {
            if let imageData = UIImageJPEGRepresentation(image, 0.1) {
                
                imagesFolder.child(imageName).putData(imageData, metadata: nil) { (metaData, error) in
                    if let error = error {
                        print(error)
                    } else {
                        
                        imagesFolder.child(self.imageName).downloadURL(completion: { (url, error) in
                            if let imageURL = url?.absoluteString {
                                self.imageURL = imageURL
                                self.performSegue(withIdentifier: "moveToSender", sender: nil)
                            }
                        })
                        
                    }
                }
            }
        }
    }
    
    @IBAction func cameraTapped(_ sender: Any) {
        imagePicker.sourceType = .camera
        present(imagePicker, animated: true, completion: nil)
    }
    
    @IBAction func choosePhotoTapped(_ sender: Any) {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let selectedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            imageView.image = selectedImage
        }
        dismiss(animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let selectVC = segue.destination as? SelectUserTableViewController {
            selectVC.imageName = imageName
            selectVC.imageURL = imageURL
            if let message = noteTextField.text {
                selectVC.message = message
            }
        }
    }
    
}
